sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("sap.btp.sapui5.controller.DetailObjectNotFound", {});
});
